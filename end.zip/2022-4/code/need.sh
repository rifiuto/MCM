awk -f need.awk Mercer-Data-processing.py > Mercer-Data-processing2.py
awk -f need.awk Mercer-Data-visualization.py > Mercer-Data-visualization2.py
awk -f need.awk Mercer-Kmeans-clustering.py > Mercer-Kmeans-clustering2.py
awk -f need.awk Mercer-LDA.py > Mercer-LDA2.py

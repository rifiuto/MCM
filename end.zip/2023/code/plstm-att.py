#PLSTM-ATT code
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import os
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error
import math

LBMA_data=pd.read_csv('LBMA_data.csv')
BCHAIN_data=pd.read_csv('BCHAIN_data.csv')

class PLSTM(object):
  _Reg_cope = 'reg_col'
  _Reg_Ratio = 0.001

  def __init__(self,
               batch_size=64,
               lr=0.01,
               mode='train',
               time_step=g_T_size):
    self._batch_size = batch_size
    self._lr = lr
    with tf.variable_scope('net'):
      self._input = tf.placeholder(dtype=tf.float32, shape=(batch_size, g_T_size, g_feat_dim), name='_input')
      self.Plstm_prob = tf.placeholder(dtype=tf.float32)

      self._build_graph()
    action_raw_loss_s = tf.summary.scalar(name='action_raw_loss', tensor=self.action_raw_loss)
    action_pred_acc_s = tf.summary.scalar(name='action_pred_acc', tensor=self.action_pred_acc)
    loss_summary_list = [action_reg_loss_s, action_raw_loss_s, action_pred_acc_s]
    self.loss_merged_op = tf.summary.merge(loss_summary_list)
    # tran summary

    pred_summary_list = [action_pred_acc_s]
    self.pred_mergerd_op = tf.summary.merge(pred_summary_list)

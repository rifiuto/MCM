# Markowitz and Dynamic Programming code
from cvxopt import matrix
import cvxopt.solvers 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import geatpy as ea
def markowitz(gold_know,gold_pre,bit_know,bit_pre):
    gold_today=gold_know[-1]
    bit_today=bit_know[-1]
    gold_gain_ratio=(gold_pre-gold_today)/gold_today
    bit_gain_ratio=(bit_pre-bit_today)/bit_today
    gain=np.array([gold_gain_ratio,bit_gain_ratio]).reshape(-1,1)
    gold_array=np.array(gold_know).reshape(-1,1)
    bit_array=np.array(bit_know).reshape(-1,1)
    before_know=np.hstack((gold_array,bit_array))
    cov=np.cov(before_know.T)
    P=matrix(cov)
    q=matrix(gain)
    G=matrix([[-1.,0.],[0.,-1.]])
    h=matrix([0.,0.])
    A=matrix([1.,1.],(1,2))
    b=matrix(1.)
    #sol.options['show_progress'] = True
    sols = sol.qp(P,q,G,h,A,b)
    invest_ratio=sols['x']
    return invest_ratio


money=1000
gold_got=0
bit_got=0
all_=(money,gold_got,bit_got)
gold_ex_ratio=0.0002
bit_ex_ratio=0.0001
everyday=[]
all_=[]
for index_1,row in BCHAIN_data.iterrows():
    date=row['Date']
    bit_know=row['Value']
    gold_can_ex=0
    if date in list(LBMA_data['Date']):
        index_2=list(LBMA_data['Date']).index(date)
        gold_know=LBMA_data['USD (PM)'][index_2]
        gold_pre=data1.pre[index_2]
        bit_pre=data2.pre[index_1]
        invest_ratio=data3.ratio[index_2]
        delta_gold=gold_pre-gold_know
        delta_bit=bit_pre-bit_know
        @ea.Problem.single
        def  evalVars(Vars):
            global money
            global gold_know
            global bit_know
            global invest_ratio
            global gold_got
            global bit_got
            global gold_ex_ratio
            global bit_ex_ratio
            global delta_gold
            global delta_bit
            x1 = Vars[0]                 
            x2 = Vars[1]              

            #pop.ObjV = 4*x1 + 2*x2 + x3
            gold_ex_ratio=0.0001
            bit_ex_ratio=0.0002
            #print(money,gold_know,bit_know,invest_ratio,gold_got,bit_got)
            f = x1*delta_gold-abs(x1*gold_ex_ratio*gold_know)+ x2*delta_bit-abs(x2*bit_ex_ratio*bit_know)
            CV = np.array([gold_know*x1-bit_know*x2+abs(x1*gold_ex_ratio)*gold_know-abs(x2*bit_ex_ratio)*bit_know-money
                                    ,(gold_got+x1)*gold_know*invest_ratio+(bit_got+x2)*bit_know*invest_ratio-gold_know*(gold_got+x1)])
            return f,CV             
        problem=problem_chose(gold_got,bit_got)
        algorithm = ea.soea_SEGA_templet(problem,
                                    ea.Population(Encoding='RI', NIND=50),
                                    MAXGEN=50,  
                                    logTras=1,
                                    trappedValue=1e-6,  
                                    maxTrappedCount=10)  
        res = ea.optimize(algorithm, seed=1, verbose=False, drawing=0, outputMsg=False, drawLog=False, saveFlag=False, dirName='result')
        if type(res['Vars'])=='Nonetype':
            solve_list=list(res['Vars'][0])

            everyday.append(res['ObjV'])
        else:
            delta_var=[0,0]
        delta_var=solve_list
        money=money-gold_know*delta_var[0]-bit_know*delta_var[1]+abs(delta_var[0]*gold_ex_ratio)*gold_know+abs(delta_var[1]*bit_ex_ratio)*bit_know
        gold_got+=delta_var[0]
        bit_got+=delta_var[1]
        all_.append((money,gold_got,bit_got))
# Markowitz and Dynamic Programming code
from cvxopt import matrix
import cvxopt.solvers 
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import geatpy as ea
# The main code
def markowitz(gold_know,gold_pre,bit_know,bit_pre):
    gold_today=gold_know[-1]
    bit_today=bit_know[-1]
    gold_gain_ratio=(gold_pre-gold_today)/gold_today
    bit_gain_ratio=(bit_pre-bit_today)/bit_today
    gain=np.array([gold_gain_ratio,bit_gain_ratio]).reshape(-1,1)
    gold_array=np.array(gold_know).reshape(-1,1)
    bit_array=np.array(bit_know).reshape(-1,1)
    before_know=np.hstack((gold_array,bit_array))
    cov=np.cov(before_know.T)
    P=matrix(cov)
    A=matrix([1.,1.],(1,2))
    b=matrix(1.)
    #sol.options['show_progress'] = True
    sols = sol.qp(P,q,G,h,A,b)
    invest_ratio=sols['x']
    return invest_ratio


